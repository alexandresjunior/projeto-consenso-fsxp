public class Exemplo01 {
    
    public static void main(String[] args) {

        String frase = "Olá, mundo!";

        // for (int i = 0; i < frase.length(); i++) {
        //     System.out.println(frase.charAt(i));
        // }
        
        int i = 0;

        while (i < frase.length()) {
            if (i % 2 == 0) {
                System.out.println(frase.charAt(i));
            }

            i++;
        }
    }

}