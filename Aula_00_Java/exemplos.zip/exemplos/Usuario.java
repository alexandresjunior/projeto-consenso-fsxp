public class Usuario implements Pessoa {

    private String nome;
    private String cpf;
    private static int numeroDeUsuarios;

    public Usuario() {
        Usuario.numeroDeUsuarios++;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public static int getNumeroDeUsuarios() {
        return numeroDeUsuarios;
    }

    public static void setNumeroDeUsuarios(int numeroDeUsuarios) {
        Usuario.numeroDeUsuarios = numeroDeUsuarios;
    }

    @Override
    public String fazerLogin() {
        return "Usuário logado com sucesso!";
    }

}
