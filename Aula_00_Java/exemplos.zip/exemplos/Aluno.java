public class Aluno extends Usuario {

    public Aluno() {
        super();
        this.matricula = null;
    }

    private String matricula;

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String dizerOla() {
        return "Olá!";
    }

    public String dizerOla(String nome) {
        return "Olá, " + nome + "!";
    }

    @Override
    public String fazerLogin() {
        return "Aluno logado com sucesso!";
    }
    
}
