public interface Pessoa {

    String fazerLogin();

}
