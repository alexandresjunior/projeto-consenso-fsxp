public class Exemplo02 {

    public static void main(String[] args) {
        Aluno aluno = new Aluno();

        aluno.setNome("Edvaldo");

        // System.out.println(aluno.getNome());
        // System.out.println(aluno.dizerOla("Alexandre"));

        // System.out.println(aluno.fazerLogin());

        Professor professor = new Professor();

        professor.setNome("Rogério");

        // System.out.println(professor.fazerLogin());

        System.out.println(Usuario.getNumeroDeUsuarios());
    }
    
}
