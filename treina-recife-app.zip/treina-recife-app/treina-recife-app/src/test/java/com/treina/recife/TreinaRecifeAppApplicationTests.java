package com.treina.recife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreinaRecifeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
