package com.treina.recife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreinaRecifeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreinaRecifeAppApplication.class, args);
	}

}
